package com.cg.Zoo;

public class MainZoo extends Zoo {
	/*void abc()
	{
		//Zoo z= new Zoo();
		test();//without object we cant do if it doesnot inherit
	}*/
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MainZoo mz=new MainZoo();
		mz.test();
	}

}
