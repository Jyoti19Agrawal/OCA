package com.cg.Zoo;

import com.jyoti.selftest.Ques5;

public class Ques22 {
	public static void main(String[] args) {
		Ques5 f = new Ques5();
		System.out.print(" " + f.a);
		System.out.print(" " + f.b);
		System.out.println(" " + f.c);
	}
}
