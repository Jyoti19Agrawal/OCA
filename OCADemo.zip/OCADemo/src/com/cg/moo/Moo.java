package com.cg.moo;

import com.cg.Zoo.Zoo;

 
public class Moo extends Zoo {
	void abc()
	{
		test();
	}

	static public void main(String[] args) {
		Moo o = new Moo();
		o.test();
		}
}
