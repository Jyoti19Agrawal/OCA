package com.cg.chapter3;

public class ScopeOfVariable {
	static int x = 10;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ScopeOfVariable s1 = new ScopeOfVariable();
		x++;
		System.out.println(x++);
		// s1.go2();
		s1.go();
		s1.go3();
	}

	void go() {
		int y = 5;
		go2();
		y++; // once go2() completes, y is back in scope
		System.out.println(y++);
	}

	void go2() {
		// y++; // won't compile, y is local to go()
		System.out.println("go2");
	}

	void go3() {
		for (int z = 0; z < 5; z++) {
			boolean test = false;
			if (z == 3) {
				test = true;
				System.out.print(test);
				break;
			}
		}
		//System.out.print(test); // 'test' is an ex-variable,
		// it has ceased to be...
	}

}
