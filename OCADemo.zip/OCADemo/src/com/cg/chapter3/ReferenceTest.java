package com.cg.chapter3;

class Dimension {
	public int width;
	public int height;
	
	
	Dimension(int l, int k) {
		super();
		width = l;
		height = k;
	}

}

public class ReferenceTest {
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Dimension d =new Dimension(5,10);
		ReferenceTest rt =new ReferenceTest();
		System.out.println("Before modify() d.height = "+d.height);
		rt.modify(d);
		System.out.println("After modify() d.height = "+d.height);
		
	}
	void modify(Dimension dim)
	{
		dim.height= dim.height+ 1;
		//dim = new Dimension(5,10); //you can't make the dimension object to refer to another object
		System.out.println("dim: "+dim.height);
	}

}
