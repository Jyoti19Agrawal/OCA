package com.cg.chapter3;

public class PrimitiveTest {

	public static void main(String[] args) {
		int a =1;
		// TODO Auto-generated method stub
		PrimitiveTest pt =new PrimitiveTest();
		System.out.println("Before Modify a = "+a);
		pt.modify(a);// copy of the "a". passed by value means passed by copy of the bits in the variable.  
		System.out.println("After modify a = "+a);
	}
	
	void modify(int num)
	{
		num = num +1;
		System.out.println("Number : "+num);
	}
}
