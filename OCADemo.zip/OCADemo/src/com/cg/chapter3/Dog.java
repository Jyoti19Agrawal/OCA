package com.cg.chapter3;

class Collar {
}

class Dog {
	Collar c; // instance variable (reference variable of collar class)
	String name; // instance variable

	public static void main(String[] args) {

		Dog d; // local variable: d
		d = new Dog();//object of dog class is assigned to local variable
		d.go(d);//copy of dog's object is pass to go()
		//d.setName("Aikoo");
	}

	void go(Dog dog) { // local variable: dog
		c = new Collar(); //object of collar class is assigned to refernce of same class
		dog.setName("Aiko");
	}

	void setName(String dogName) { // local var: dogName
		name = dogName; // local and instance both refer to same string object
		System.out.println(name);
		// do more stuff
	}
}

 
