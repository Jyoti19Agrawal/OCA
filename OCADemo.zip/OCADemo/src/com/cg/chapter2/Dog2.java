package com.cg.chapter2;

class Animals {
	public void eat() throws Exception {
		// throws an Exception
		System.out.println("Animal");
	}
}

public class Dog2 extends Animals {

	public void eat() throws Exception { /* no Exceptions */
		System.out.println("Dog");
	}

	public static void main(String[] args) {
		Animals a = new Dog2();
		Animals b= new Animals();
		Dog2 d = new Dog2();
		//d.eat(); // ok
		
	 try {
			b.eat();
			a.eat(); // compiler error -
			// unreported exception
			d.eat(); // ok
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
	}
}
