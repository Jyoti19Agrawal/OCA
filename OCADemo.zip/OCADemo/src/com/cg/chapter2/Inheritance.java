package com.cg.chapter2;

class Animal {
	public void eat() {
		System.out.println("Generic Animal Eating Generically");
	}
	
}

class Horse extends Animal {
	
	public void eat() {
		super.eat();
		System.out.println("Horse eating hay, oats, " + "and horse treats");
	}
	
	
	public void buck() {
		System.out.println("Buck Method");
	}
	
	//overloading and overriding are taking together in horse
	public void eat(String s) {
		this.eat();// to call the default eat()
		System.out.println("Horse eating " + s);
		}
	
}

public class Inheritance {
	// public class TestAnimals {
	public static void main(String[] args) {
		//Animal a = new Animal();
		Animal b = new Horse(); // Animal ref, but a Horse object
		Horse h=new Horse();
		h.eat("Horse");
		
		//a.eat(); // Runs the Animal version of eat()
		b.eat(); // Runs the Horse version of eat()
		//b.buck();// error coz b is of animal reference
		//a.buck();//CT error coz buck is of type horse ref
	}
}

//if you dont want to make reference of animal type then call super method using super keyword