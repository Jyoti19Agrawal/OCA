package com.cg.chapter2;

import java.io.IOException;


class Bar {
	public void doStuff(int y, long s)  {
		y = 10;
		s = 100;
		System.out.println("Addition is "+(y+s));
	}
}
public class OverLoad extends Bar {
	// public class Foo {
	public void doStuff(int y, String s) throws IOException {
		y=10;
		s= "Overload";
		System.out.println("Dostuff Of String Type "+s+" "+y);
	}

	public String moreThings(int x) {
		int y=2;
		x=y+10;
		String s=x+"";
		//System.out.println("MoreThings "+x);
		return s;
	}
	public static void main(String[] args) {
		OverLoad o= new OverLoad();
		System.out.println(o.moreThings(4));
		o.doStuff(1, 10);
		try {
			o.doStuff(1, "abc");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}


