package com.cg.chapter2;

public class ConstructorOverloading {
	String name;

	ConstructorOverloading(String name) {
		//this();
		this.name = name;
		
	}

	ConstructorOverloading() {
		this(makeRandomName());
	 
	}

	static String makeRandomName() {

		int x = (int) (Math.random() * 5);
		String name = new String[] { "Fluffy", "Fido", "Rover", "Spike", "Gigi" }[x];
		return name;
	}
	
	 

	public static void main(String[] args) {
		ConstructorOverloading a = new ConstructorOverloading();
		System.out.println(a.name);
		System.out.println(ConstructorOverloading.makeRandomName());
		ConstructorOverloading b = new ConstructorOverloading("Zeus");
		System.out.println(b.name);
	}

}
