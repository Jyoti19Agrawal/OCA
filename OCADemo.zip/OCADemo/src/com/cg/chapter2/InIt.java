package com.cg.chapter2;

/*class InIt {
	InIt(int x) {
		System.out.println("1-arg const");
	}

	InIt() {
		System.out.println("no-arg const");
	}

	static {
		System.out.println("1st static init");
	}
	{
		System.out.println("1st instance init");
	}
	{
		System.out.println("2nd instance init");
	}
	static {
		System.out.println("2nd static init");
	}

	public static void main(String[] args) {
		new InIt();
		new InIt(7);
	}

}
 */

//When static init block throws exception

class InitError {
	static int[] x = new int[4];
	static {
		x[4] = 5;
	} // bad array index!

	public static void main(String[] args) {
	}
}