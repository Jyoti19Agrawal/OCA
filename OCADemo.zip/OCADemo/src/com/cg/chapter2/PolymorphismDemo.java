package com.cg.chapter2;

interface Animatable {
	public void animate();
}

class PlayerPieces extends GameShape implements Animatable {
	public void movePiece() {
		System.out.println("moving game piece");
	}

	public void animate() {
		System.out.println("animating...");
	}
	// more code
}

public class PolymorphismDemo {
	public static void main(String[] args) {
		PlayerPieces p=new PlayerPieces();
		p.displayShape();
		p.animate();
		p.movePiece();
	}
	
}
