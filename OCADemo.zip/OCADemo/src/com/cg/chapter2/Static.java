package com.cg.chapter2;

class Static {

 static int frogCount = 0; // Declare and initialize

 // static variable
 public Static() {
 frogCount += 1;
 //System.out.println(frogCount);// Modify the value in the constructor
 }

 public static void main(String[] args) {
 Static s1= new Static();
 Static s2=new Static();
 Static s3=new Static();
 //System.out.println("Frog count is now " + frogCount);//CT error without static keyword in instance variable
 }

 }
 

/*class Static {
	 int x = 3;

	public static void main(String[] args) {
		System.out.println("x is " + new Static().x);//either this or make variable a static variable
	}
}*/