package com.cg.chapter2;

class Animald {
	void makeNoise() {
		System.out.println("generic noise");
	}
}

class Dog extends Animald {
	void makeNoise() {
		System.out.println("bark");
	}

	void playDead() {
		System.out.println("roll over");
	}
}

public class Typecasting {
	public static void main(String[] args) {
		Typecasting t =new Typecasting();
		Dog d =new Dog();
		/*if (t instanceof Dog)//CT error because we can't compare two class hierarchy
		{
			System.out.println("Dog's instance");
		}*/
		Animald[] a = { new Animald(), new Dog(), new Animald() };
		for (Animald animal : a) 
			animal.makeNoise();
			if (animal instanceof Dog) {
				Dog d = (Dog)animal;// because array itself is a object
				d.playDead(); // try to do a Dog behavior?
			}
			if (new Dog() instanceof Animald)
			{
				System.out.println("Dog is a Animal");
			}
		}
		
		/*Animald animal = new Animald();
		Dog d = (Dog) animal;*/
		//String s = (String) animal; // animal can't EVER be a String inconvertible type
		/*Animald a = new Dog();
		Dog d1 = (Dog) a;
		d1.playDead();*/
	
	
}
