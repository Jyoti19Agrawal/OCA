package com.cg.chapter2;

/*public class Static2 {
 static int frogSize = 0;

 public int getFrogSize() {
 return frogSize;
 }

 public Static2(int s) {
 frogSize = s;
 }

 public static void main(String[] args) {
 Static2 f = new Static2(25);
 int a = Static2.frogSize;
 System.out.println(f.getFrogSize());// both way i can do
 System.out.println(a); // Access instance
 // method using f
 }

 }
 */

class Plant {
	static void doStuff() {
		System.out.print("a ");
	}
}

class Static2 extends Plant {
	static void doStuff() { // it's a redefinition,
	// not an override
		System.out.print("d ");
	}

	public static void main(String[] args) {
		Plant[] a = { new Plant(),new Static2(),new Plant() };
		//Static2[] a={new Static2()};
		for (int x = 0; x < a.length; x++) {
			a[x].doStuff(); // invoke the static method
		}
		Static2.doStuff(); // invoke using the class name
	}
}