package com.jyoti.selftest;

interface Gadget {
	void doStuff();
}

abstract class Electronic {
	void getPower() {
		System.out.print("plug in ");
	}
}

public class Ques10 extends Electronic implements Gadget {
	public void doStuff() {//CTerror without public modifier
		System.out.print("show book ");
	}

	public static void main(String[] args) {
		new Ques10().getPower();
		new Ques10().doStuff();
	}
}
