package com.jyoti.selftest;

public class Ques5 {
	int a = 5;
	protected int b = 6;
	public int c = 7;
}
