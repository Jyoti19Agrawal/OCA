package com.jyoti.selftest;

public class Ques8 {
	public enum Days {
		MON, TUE, WED
	};

	public static void main(String[] args) {
		for (Days d : Days.values());
		/*{
			System.out.println(d);
		}*/
			
		Days[] d2 = Days.values();
		System.out.println(d2[2]);
	}
}
