package com.jyoti.selftest;

class Ques7 {
	public static void main(String[] args) {
		 for(int __x = 0; __x < 3; __x++) ;
		 int #lb = 7;//CT
		 long [] x [5];//CT
		Boolean []ba[];
		 }
}
