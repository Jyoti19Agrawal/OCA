package com.jyoti.selftest;


enum Animals {
	DOG("woof"), CAT("meow"), FISH("burble");
	String sound;

	Animals(String sound) {
		this.sound = sound;
	}
	String getSound()
	{
		return sound;
	}
	
}
 
	class Ques4 {
		static Animals a;

		public static void main(String[] args) {
			System.out.println(a.DOG.sound + " " + a.FISH.sound);
		}
	}


