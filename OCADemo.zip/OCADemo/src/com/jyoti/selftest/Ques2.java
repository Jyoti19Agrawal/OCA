package com.jyoti.selftest;


class Rocket {
	private void blastOff() { System.out.print("bang "); }
	}
public class Ques2 extends Rocket {
	
		public static void main(String[] args) {
		new Ques2().go();
		}
		void go() {
		blastOff();
		//Rocket.blastOff(); // line A
		}
		private void blastOff() { System.out.print("sh-bang "); }
		}

