package com.jyoti.selftest;

public class Ques9 extends Hobbit{ 
	 public static void main(String[] args) {
		 Hobbit h=new Hobbit();
	int myGold = 7;
	 System.out.println(h.countGold(myGold, 6));//without references CT error
 }
	 }
	 class Hobbit {
	 int countGold(int x, int y) { return x + y; }
	 }

