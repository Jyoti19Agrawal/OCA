package com.jyoti.selftest2;

class Dog {
	public void bark() {
		System.out.print("woof ");
	}
	public void sniff() {
		System.out.print("sniff Parent ");
	}
}

class Hound extends Dog {
	public void sniff() {
		System.out.print("sniff ");
	}

	public void bark() {
		System.out.print("howl ");
	}
}

public class DogShow {
	public static void main(String[] args) {
		Dog d=(Hound) new Dog();
		new DogShow().go();
		d.bark();
	}

	void go() {
		new Hound().bark();

		((Dog) new Hound()).bark();
		((Dog) new Hound()).sniff();
	}
}
