package com.jyoti.selftest2;

class X {
	void do1() {
	}
}

class Y extends X {
	void do2() {
		System.out.println("Hello");
	}
}

class Ques6 {
	public static void main(String[] args) {
		X x1 = new X();
		X x2 = new Y();
		Y y1 = new Y();
		// insert code here
		/*x2.do2();
		(Y)x2.do2();  //CT error*/
		((Y)x2).do2();
	}
}
