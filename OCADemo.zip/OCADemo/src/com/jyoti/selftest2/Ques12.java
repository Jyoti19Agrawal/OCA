package com.jyoti.selftest2;

class Building {
	Building() {
		System.out.print("b ");
	}

	Building(String name) {
		this();
		System.out.print("bn " + name);
	}
}

public class Ques12 extends Building {
	Ques12() {
		System.out.print("h ");
	}

	Ques12(String name) {
		this();
		System.out.print("hn " + name);
	}

	public static void main(String[] args) {
		//new Building("y ");
		new Ques12("x ");
	}
}
