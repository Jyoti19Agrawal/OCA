package com.jyoti.selftest2;

public class Ques9 extends Tree {
	public static void main(String[] args) {
		new Ques9().go();
	}

	void go() {
		go2(new Tree(), new Ques9());
		go2((Ques9) new Tree(), new Ques9());
	}

	void go2(Tree t1, Ques9 r1) {
		Ques9 r2 = (Ques9) t1;
		Tree t2 = (Tree) r1;
	}
}

class Tree {
}

 
