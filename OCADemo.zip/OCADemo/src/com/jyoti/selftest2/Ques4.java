package com.jyoti.selftest2;


class AgedP {
	
public AgedP(int x) {
}
}
public class Ques4 extends AgedP {
public Ques4(int x) {
 ();
}
}
 