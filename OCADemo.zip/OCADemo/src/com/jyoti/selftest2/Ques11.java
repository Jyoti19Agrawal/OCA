package com.jyoti.selftest2;

class Alpha {
	static String s = " ";

	protected Alpha() {
		s += "alpha ";
	}
}

class SubAlpha extends Alpha {
	private SubAlpha() {
		s += "sub ";
	}
}

public class Ques11 extends Alpha {
	private Ques11() {
		s += "subsub ";
		//System.out.println(s);
	}

	public static void main(String[] args) {
		new Ques11();
		System.out.println(s);
	}
}
