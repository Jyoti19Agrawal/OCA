package com.jyoti.selftest2;

class Clidder {
	private final void flipper() {
		System.out.println("Clidder");
	}
}

public class Ques3 extends Clidder {
	public final void flipper() {
		System.out.println("Clidlet");
	}

	public static void main(String[] args) {
		new Ques3().flipper();
	}
}

 