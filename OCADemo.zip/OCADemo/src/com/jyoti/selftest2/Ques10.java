package com.jyoti.selftest2;

public class Ques10 extends Singer {
	public static String sing() {
		return "fa";
	}

	public static void main(String[] args) {
		Ques10 t = new Ques10();
		Singer s = new Ques10();
		System.out.println(t.sing() + " " + s.sing());
	}
}

class Singer {
	public static String sing() {
		return "la";
	}
}

 
