package com.jyoti.selftest2;

class Top1 {
	/*public Top1()
	{}*/
	public Top1(String s) {
		System.out.print("B");
	}
}

public class Bottom2 extends Top1 {
	public Bottom2(String s) {
		super("A");
		System.out.print("D");
	}

	public static void main(String[] args) {
		new Bottom2("C");
		System.out.println(" ");
	}
}
