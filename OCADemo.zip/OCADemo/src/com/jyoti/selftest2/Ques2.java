package com.jyoti.selftest2;

class Top {
	
	public Top() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Top(String s) {
		System.out.print("B");
	}
}

public class Ques2 extends Top {
	//CT error coz super class does not have default constructor
	public Ques2(String s) {
		System.out.print("D");
	}
	
	

	public static void main(String[] args) {
		new Ques2("C");
		System.out.println(" ");
	}

}
