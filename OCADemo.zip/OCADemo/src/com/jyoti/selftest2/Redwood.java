package com.jyoti.selftest2;

public class Redwood extends Tree11 {
	public static void main(String[] args) {
		new Redwood().go();
	}

	void go() {
		go2(new Tree11(), new Redwood());
		go2((Redwood) new Tree11(), new Redwood());
	}

	void go2(Tree11 t1, Redwood r1) {
		Redwood r2 = (Redwood) t1;
		Tree11 t2 = (Tree11) r1;
	}
}

class Tree11 {
}
