public class LocalVariables {
	int u = 10;
	void doStuff() {
		//int u;
		int u = 7;
		this.doMore(u);
		System.out.println("Local Variable : "+u);
	}

	private void doMore(int x) {
		// TODO Auto-generated method stub
		x = u;
		System.out.println("Instance variable " +x);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LocalVariables lm = new LocalVariables();
		lm.doStuff();
	}

}
