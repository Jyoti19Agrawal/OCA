
public class MainInterface {

	public static void main(String[] args) {
		 InterfaceDemo.kiss();
	}

}
