
public class Array {
	
	int[] key;
	
	final int a= 10;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Array a= new Array();
		int b= a.a;
		System.out.println(b);
	}

}
