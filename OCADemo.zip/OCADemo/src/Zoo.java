
public class Zoo {

	/*public String coolMethod() {
		return "Wow baby";
		}
		
		public void doStuff()
	{
		coolMethod();
	}*/
		
	
	//-------------------Private-----------------------------
	/*private String coolMethod() {
		return "Wow baby";
		
		//cannot be access anywhere
	}*/
	//--------------------Default-------------------------
	
	int x= 2;
	void test()
	{
		System.out.println("Default Method");
	}
	
	
	
	//---------------Protected------------------
	/*protected void test()
	{
		System.out.println("Protected Method");
	}
*/}
