
class A {

	public final void showSample() {
		System.out.println("One thing.");
		}
}
	public class FinalKey{
		public final void showSample(int first, final int last) { // Try to override the final
		// superclass method
		System.out.println("Another thing.");
		//first = 10;
		System.out.println(first+" "+last);
		}

	public static void main(String[] args) {
		FinalKey f= new FinalKey();
		f.showSample(2, 8);

	}

}
