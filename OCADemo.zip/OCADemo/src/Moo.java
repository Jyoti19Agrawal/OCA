
class Moo extends Zoo{
	/*public void useCoolMethod(){
		//Zoo z= new Zoo();
		//System.out.println(z.coolMethod());
		System.out.println(coolMethod());//this. implicitly call hoga
		System.out.println("hello");
	}
	
	public void doMore()
	{
		coolMethod();
	}
*/
	
	//-------------Private------------------
	
	/*private void coolMethod()
	
	{
		System.out.println("hello");
	}*/
	
	//------------Default-----------------------------
	Zoo z= new Zoo();
	int y = z.x;//wcan do both with and without object
	void test1()
	{
		Zoo z= new Zoo(); 
	z.test();
	}
	
	//--------------protected---------------------------
	
	/*protected void test1()
	{
		Zoo z=new Zoo();
	z.test();
		test();
	}*/
}
