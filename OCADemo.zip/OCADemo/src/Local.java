
public class Local {

	int x = 10;
	
	void foo(int x)
	{
		x = this.x;
		System.out.println("Variable :"+x);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Local l=new Local();
		l.foo(3);
	}

}
