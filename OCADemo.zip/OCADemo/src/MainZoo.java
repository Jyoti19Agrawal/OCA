
public class MainZoo extends Moo {

	
	//-----------------------private-------------------
	/*private void coolMethod()
	{
		System.out.println("In main hello");
	}*/
	
	public static void main(String[] args) {
		
		//-----------------------private-------------------
		/*MainZoo m=new MainZoo();
		 m.coolMethod();
		 //m.doMore();
*/
		
		
		//----------------default------------------------
		Moo m=new Moo();
		int g=m.y;
		System.out.println("Variable of X : "+g);;
	}

}
