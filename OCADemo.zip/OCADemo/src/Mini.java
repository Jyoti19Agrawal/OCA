 abstract class AbstractClass {
	private String type ="abc";
/*public abstract void goUpHill(); */
	static void goUpHill()// we can make it static also
	{
		System.out.println("Parent class");
	}// Abstract method

	public String getType() { // Non-abstract method
		return type;
	}

}

abstract class Car extends AbstractClass {
	//public abstract void goUpHill(); // Still abstract

	public void doCarThings(int i) {
		System.out.println("car class");
		i = 10;
		System.out.println(i);
	}
}

public class Mini extends Car {
	static void goUpHill() {
		// Mini-specific going uphill code
		System.out.println("Mini class");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Mini m = new Mini();
		AbstractClass.goUpHill();// will call parent class
		//m.goUpHill(); //will call child class
		m.doCarThings(7);
		System.out.println(m.getType());
		
	}

}
