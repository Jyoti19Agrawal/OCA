public interface InterfaceDemo{
	
	int BAR = 42;
	 public void Bounce();
	 void Put();
	 public abstract void get();
	 abstract public void Cut();
	 public static void kiss() {
		 System.out.println("static method");
	}

}

//method cant be static beacuse cannot be override