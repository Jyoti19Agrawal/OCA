
public class InterfaceImpl implements InterfaceDemo {

	@Override
	public void Bounce() {
	System.out.println("Hello");
		
	}

	@Override
	public void Put() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void get() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void Cut() {
		// TODO Auto-generated method stub
		
	}
	
	public static void kiss()
	{
		System.out.println("hello");
	}
	 
}
