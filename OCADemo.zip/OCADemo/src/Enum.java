/*enum CoffeeSize{
	BIG, OVERWHELMING,HUGE  //eac enum type has its index position.
}
public class Enum {

	CoffeeSize coffee;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Enum e=new Enum();
		e.coffee= CoffeeSize.BIG;
		System.out.println(CoffeeSize.BIG);
		//CoffeeSize e = CoffeeSize.BIG;
		//System.out.println(e);
	}

}
 */

enum CoffeeSize {
	// 8, 10 & 16 are passed to the constructor
	BIG(8, "A"), HUGE(10, "B"), OVERWHELMING(16,"C");
	CoffeeSize(int ounces, String lid) { // constructor by default private
		this.ounces = ounces;
		this.lid = lid;
	};

	private int ounces;
	private String lid;// an instance variable

	public int getOunces() {
		return ounces;
		
	}
	public String getLid()
	{
		return "A";
		//return lid;
	}
	

}

public class Enum {
	CoffeeSize size; // each instance of Coffee has an enum

	public static void main(String[] args) {
		Enum drink1 = new Enum();
		drink1.size = CoffeeSize.BIG;
		Enum drink2 = new Enum();
		drink2.size = CoffeeSize.OVERWHELMING;
		System.out.println(drink1.size.getOunces()); // prints 8
		System.out.println(drink2.size.getOunces());
		System.out.println(drink1.size.getLid());
		System.out.println(drink2.size.getLid());
		for (CoffeeSize cs : CoffeeSize.values())
			System.out.println(cs + " " + cs.getOunces()+" "+cs.getLid());
	}
}
